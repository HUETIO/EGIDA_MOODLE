import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import type { UserProfile, UserRole } from '../src/shared/types.ts';
import type { EgidaStore } from './store.ts';

const EPHEMERAL_SECRET = crypto.randomBytes(32).toString('hex');

function getSessionSecret(): string {
  return process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16
    ? process.env.SESSION_SECRET
    : EPHEMERAL_SECRET;
}

export interface SessionPayload {
  userId: string;
  role: UserRole;
  exp: number;
}

export function signSessionToken(user: UserProfile, ttlSeconds = 60 * 60 * 8): string {
  const payload: SessionPayload = {
    userId: user.id,
    role: user.role,
    exp: Math.floor(Date.now() / 1000) + ttlSeconds,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf-8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifySessionToken(token: string): SessionPayload | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, sig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');
  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf-8')) as SessionPayload;
    if (!parsed.userId || !parsed.role || parsed.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export interface AuthenticatedRequest extends Request {
  currentUser: UserProfile;
  isAnonymousReadOnly: boolean;
}

export function createAuthMiddleware(store: EgidaStore) {
  const attachUser = (req: Request, _res: Response, next: NextFunction) => {
    const authReq = req as AuthenticatedRequest;
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.slice('Bearer '.length).trim();
      const payload = verifySessionToken(token);
      if (payload) {
        const user = store.state.users.find((u) => u.id === payload.userId);
        if (user) {
          authReq.currentUser = user;
          authReq.isAnonymousReadOnly = user.role === 'solo_lectura';
          return next();
        }
      }
    }
    // Default unauthenticated fallback: strict read-only guest profile
    const guest = store.state.users.find((u) => u.role === 'solo_lectura') ?? {
      id: 'solo-lectura',
      email: 'visitante@institucion-ejemplo.edu.co',
      displayName: 'Visitante Institucional (Solo lectura)',
      role: 'solo_lectura' as const,
      profileContext: 'Consulta pública',
      assignedCourseIds: [],
      enrolledCourseIds: [],
      preferences: { largeText: false, highContrast: false, timezone: 'America/Bogota' },
    };
    authReq.currentUser = guest;
    authReq.isAnonymousReadOnly = true;
    next();
  };

  const requireAuthenticatedRole = (req: Request, res: Response, next: NextFunction) => {
    const authReq = req as AuthenticatedRequest;
    if (authReq.currentUser.role === 'solo_lectura') {
      store.addAudit({
        actorId: authReq.currentUser.id,
        actorRole: authReq.currentUser.role,
        action: 'ACCESO_DENEGADO_SOLO_LECTURA',
        resourceType: 'route',
        resourceId: req.path,
        outcome: 'denegado',
        detail: 'Modo solo lectura intentó acceder a operación protegida.',
      });
      return res.status(403).json({
        error: 'Acceso no autorizado para la vista de solo lectura.',
      });
    }
    next();
  };

  const requireCourseReadAccess = (req: Request, res: Response, next: NextFunction) => {
    const authReq = req as AuthenticatedRequest;
    const courseId = req.params.courseId;
    const course = store.state.courses.find((c) => c.id === courseId);
    if (!course) {
      return res.status(404).json({ error: 'Recurso no disponible.' });
    }
    const user = authReq.currentUser;
    if (user.role === 'solo_lectura') {
      if (!course.published || !course.readOnlyPolicy.allowCatalogCard) {
        return res.status(403).json({ error: 'Acceso no autorizado al recurso solicitado.' });
      }
      return next();
    }
    if (user.role === 'profesor' && !user.assignedCourseIds.includes(courseId)) {
      store.addAudit({
        actorId: user.id,
        actorRole: user.role,
        action: 'ACCESO_DENEGADO_CURSO_AJENO',
        resourceType: 'course',
        resourceId: courseId,
        courseId,
        outcome: 'denegado',
        detail: 'Profesor intentó consultar curso no asignado.',
      });
      return res.status(403).json({ error: 'No tiene autorización sobre este curso.' });
    }
    if (user.role === 'estudiante' && (!course.published || !user.enrolledCourseIds.includes(courseId))) {
      store.addAudit({
        actorId: user.id,
        actorRole: user.role,
        action: 'ACCESO_DENEGADO_NO_MATRICULADO',
        resourceType: 'course',
        resourceId: courseId,
        courseId,
        outcome: 'denegado',
        detail: 'Estudiante intentó consultar curso sin matrícula activa.',
      });
      return res.status(403).json({ error: 'No tiene autorización sobre este curso.' });
    }
    next();
  };

  const requireProfessorOfCourse = (req: Request, res: Response, next: NextFunction) => {
    const authReq = req as AuthenticatedRequest;
    const courseId = req.params.courseId;
    const user = authReq.currentUser;
    if (user.role !== 'profesor' || !user.assignedCourseIds.includes(courseId)) {
      store.addAudit({
        actorId: user.id,
        actorRole: user.role,
        action: 'ACCESO_DOCENTE_DENEGADO',
        resourceType: 'teacher_area',
        resourceId: req.path,
        courseId,
        outcome: 'denegado',
        detail: 'Intento de acceso administrativo docente sin asignación en el curso.',
      });
      return res.status(403).json({ error: 'Operación reservada al profesor asignado al curso.' });
    }
    next();
  };

  return {
    attachUser,
    requireAuthenticatedRole,
    requireCourseReadAccess,
    requireProfessorOfCourse,
  };
}
